from django.apps import AppConfig


class FirstAppsConfig(AppConfig):
    name = 'first_apps'
