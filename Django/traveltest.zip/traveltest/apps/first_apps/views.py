from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from django.core.urlresolvers import reverse
from .models import *

# Create your views here.
def index(request):
	return render(request, 'index.html')
	
def create(request):
	 if User.objects.registration_validator(request.POST, request):
	 	passFlag=True
	 	User.objects.create(first_name=request.POST['first_name'],
			last_name=request.POST['last_name'],email=request.POST['email'],
			password=request.POST['password']) 
	 	user = User.objects.get(email=request.POST['email'])
	 	return redirect(reverse('display',kwargs={'id': user.id }))
	 else:
	 	return redirect(reverse('index'))

def login(request):
	
	if User.objects.login_validator(request.POST, request):
		passFlag = True
		user = User.objects.get(email=request.POST['email_login'])
		return redirect(reverse('display',kwargs={'id': user.id }))
	else:
		return redirect(reverse('index',kwargs={'id': user.id }))

def display(request, id):
	context = {
		'user': User.objects.get(id= id),
		'trips': Trips.objects.all()
	}
	return render(request, 'welcome.html', context)

def viewtrip(request, id):
	
	logged_in_user=User.objects.get(id= id)
	current_user= logged_in_user.created_trips.all()
	other_users= Trips.objects.exclude(creator=logged_in_user)
	context = {
		'logged_in_user' : logged_in_user,
		'current_user' : current_user,
		'other_users' : other_users,
		'trips' : Trips.objects.all()
	}

	return render(reverse(request, 'viewtrip.html', context))

def addtrip(request, id):

	return render(reverse(request, 'addtrip.html'))
	print(request.POST)

	
def createtrip(request, id):
	logged_in_user = User.objects.get(id = id)
	Trips.objects.create(destination=request.POST['name'],
		description=request.POST['plan'], date_from=request.POST['travel_start'],date_to=request.POST['travel_end'])

	return redirect(reverse('display',kwargs={'id': id }))


def logout(request, id):
	request.session.flush()
	return redirect('index')

